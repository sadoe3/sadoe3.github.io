#include "filesys/filesys.h"
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include "filesys/file.h"
#include "filesys/free-map.h"
#include "filesys/inode.h"
#include "filesys/directory.h"

#include "threads/thread.h"


/* Partition that contains the file system. */
struct block *fs_device;

static void do_format (void);

/* Initializes the file system module.
   If FORMAT is true, reformats the file system. */
void
filesys_init (bool format) 
{
  /* initialize buffer cache 
  for(unsigned current_count = 0; current_count < CACHE_COUNT; ++current_count) {
    buffer_caches[current_count].buffer_cache = malloc(BLOCK_SECTOR_SIZE);
    if(buffer_caches[current_count].buffer_cache == NULL)
      exit(-1);
    buffer_caches[current_count].sector_index = 0;
  }
  */
  
  fs_device = block_get_role (BLOCK_FILESYS);
  if (fs_device == NULL)
    PANIC ("No file system device found, can't initialize file system.");

  inode_init ();
  free_map_init ();

  if (format) 
    do_format ();

  free_map_open ();

  struct dir *root_dir = dir_open_root();
  thread_current()->current_directory = root_dir;
  dir_add (root_dir, ".", ROOT_DIR_SECTOR);
}

/* Shuts down the file system module, writing any unwritten data
   to disk. */
void
filesys_done (void) 
{
  /* flush buffer cache 
  for(unsigned current_count; current_count < CACHE_COUNT; ++current_count) {
    if(buffer_caches[current_count].is_dirty)
      block_write(fs_device, buffer_caches[current_count].sector_index, buffer_caches[current_count].buffer_cache);
  }
  */
  free_map_close ();
}


/* Parses the given path */
struct dir *parse_path (const char *original_path, char *file_name) {
  struct dir *dir = NULL;
  if (original_path == NULL || file_name == NULL)
    return NULL;
  if (strlen(original_path) == 0)
    return NULL;

  char path[PATH_MAX_LENGTH + 1];
  strlcpy(path, original_path, PATH_MAX_LENGTH);

  if (path[0] == '/') 
    dir = dir_open_root();
  else
    dir = dir_reopen(thread_current()->current_directory);

  if(is_inode_valid_directory(dir_get_inode(dir)) == false)
    return NULL;

  char *token, *next_token, *save_ptr;
  token = strtok_r(path, "/", &save_ptr);
  next_token = strtok_r(NULL, "/", &save_ptr);

  if(token == NULL) {
    strlcpy(file_name, ".", PATH_MAX_LENGTH);
    return dir;
  }
  
  while(token && next_token) {
    struct inode *inode = NULL;
    if(dir_lookup (dir, token, &inode) == false) {
      dir_close(dir);
      return NULL;
    }
    if (is_inode_valid_directory(inode) == false) {
      dir_close(dir);
      return NULL;
    }
    dir_close(dir);
    dir = dir_open(inode);

    token = next_token;
    next_token = strtok_r(NULL, "/", &save_ptr);
  }
  strlcpy(file_name, token, PATH_MAX_LENGTH);
  return dir;
}


/* Creates a file named NAME with the given INITIAL_SIZE.
   Returns true if successful, false otherwise.
   Fails if a file named NAME already exists,
   or if internal memory allocation fails. */
bool
filesys_create (const char *path, off_t initial_size) 
{
  block_sector_t inode_sector = 0;
  char name[PATH_MAX_LENGTH + 1];
  struct dir *dir = parse_path(path, name);

  bool success = (dir != NULL
                  && free_map_allocate (1, &inode_sector)
                  && inode_create (inode_sector, initial_size, false)
                  && dir_add (dir, name, inode_sector));
  if (!success && inode_sector != 0) 
    free_map_release (inode_sector, 1);
  dir_close (dir);

  return success;
}

/* Creates a directory */
bool filesys_create_dir(const char *path) {
  block_sector_t inode_sector = 0;
  char name[PATH_MAX_LENGTH + 1];
  struct dir *dir = parse_path(path, name);

  bool success = (dir != NULL
                  && free_map_allocate (1, &inode_sector)
                  && dir_create (inode_sector, 16)
                  && dir_add (dir, name, inode_sector));
  if(!success && inode_sector != 0)
    free_map_release (inode_sector, 1);

  if(success) {
    struct dir *new_dir = dir_open(inode_open(inode_sector));
    dir_add (new_dir, ".", inode_sector);
    dir_add (new_dir, "..", inode_get_inumber(dir_get_inode(dir)));
    dir_close (new_dir);
  }
  dir_close (dir);
  return success;
}


/* Opens the file with the given NAME.
   Returns the new file if successful or a null pointer
   otherwise.
   Fails if no file named NAME exists,
   or if an internal memory allocation fails. */
struct file *
filesys_open(const char *path) {
  char name[PATH_MAX_LENGTH + 1];
  struct dir *dir = parse_path(path, name);
  struct inode *inode = NULL;
  if(dir != NULL)
    dir_lookup(dir, name, &inode);
  dir_close(dir);
  return file_open(inode);
}

/* Deletes the file named NAME.
   Returns true if successful, false on failure.
   Fails if no file named NAME exists,
   or if an internal memory allocation fails. */
bool
filesys_remove (const char *path)  {
  char name[PATH_MAX_LENGTH + 1];
  struct dir *dir = parse_path(path, name);
  bool success = false;

  if(dir != NULL) {
    struct inode *target_inode = NULL;
    if(dir_lookup(dir, name, &target_inode) == false)
      return false;
    if(is_inode_valid_directory(target_inode) == false) {
      inode_close(target_inode);
      success = dir_remove(dir, name);
    }
    else {
      char temp_name[PATH_MAX_LENGTH + 1];
      struct dir *dir_to_check = dir_open(target_inode);
      char previous_name[PATH_MAX_LENGTH + 1];
      for(int i = 0; i < 3; ++i) {
        dir_readdir(dir_to_check, temp_name);
        if(strcmp(temp_name, "..") == 0 && strcmp(previous_name, temp_name) == 0) {
          success = true;
          break;
        }
        strlcpy(previous_name, temp_name, sizeof(previous_name));
      }
      dir_close(dir_to_check);
      // remove directory only it's empty
      if(success)
        success = dir_remove(dir, name);
    }
  }

  dir_close(dir);
  return success;
}

/* Formats the file system. */
static void
do_format (void)
{
  printf ("Formatting file system...");
  free_map_create ();
  if (!dir_create (ROOT_DIR_SECTOR, 16))
    PANIC ("root directory creation failed");
  free_map_close ();
  printf ("done.\n");
}
