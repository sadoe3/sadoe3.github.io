#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

#include "threads/vaddr.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "userprog/process.h"

#include "vm/page.h"
#include "filesys/inode.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  is_from_systemcall = false;
  lock_init(&filesys_lock);
  lock_init(&paging_lock);
}

bool is_valid_address(void *ptr) {
  if(ptr != NULL && is_user_vaddr(ptr) == true) {
    if(pagedir_get_page(thread_current()->pagedir, ptr) != NULL)
      return true;
    else {
      is_from_systemcall = true;
      int* trigger_to_handler = ptr;
      *trigger_to_handler = 0;
      is_from_systemcall = false;
      if(pagedir_get_page(thread_current()->pagedir, ptr) != NULL)
        return true;
    }
  }
  return false;
}

void halt(void) {
  shutdown_power_off();
}

void exit(int status) {
  if(status < 0)
    status = -1;
  struct thread *current_thread = thread_current();
  printf("%s: exit(%d)\n", current_thread->name, status);
  current_thread->exit_status = status;

  thread_exit();
}

int exec(const char *cmd_line) {
  if(is_valid_address(cmd_line) == false) 
    return -1;

  const unsigned MAX_PROCESS_NAME_COUNT = 32;
  char new_process_name[MAX_PROCESS_NAME_COUNT];
  strlcpy(new_process_name, cmd_line, MAX_PROCESS_NAME_COUNT);
  char *saveptr, *token = strtok_r(new_process_name, " ", &saveptr);  
  lock_acquire(&filesys_lock);
  struct file *temp_file = file_open(token);
  if(temp_file == NULL) {
    lock_release(&filesys_lock);
    return -1;
  }
  file_close(temp_file);
  lock_release(&filesys_lock);

  return process_execute(cmd_line);
}

int wait(int pid) {
  return process_wait(pid);
}

bool create(const char *file, unsigned initial_size) {
  if(is_valid_address(file) == false)
    exit(-1);

  lock_acquire(&filesys_lock);
  int return_value = filesys_create(file, initial_size);
  lock_release(&filesys_lock);

  return return_value;
}

bool remove(const char *file) {
  lock_acquire(&filesys_lock);
  int return_value = filesys_remove(file);
  lock_release(&filesys_lock);
  
  return return_value;
}

int open(const char *file) {
  if(is_valid_address(file) == false)
    exit(-1);

  lock_acquire(&filesys_lock);

  struct file *current_file = filesys_open(file);
  if(current_file == NULL) {
    lock_release(&filesys_lock);
    return -1;
  }

  struct thread *current_thread = thread_current();
  if(current_thread->next_fd == -1) {
    file_close(current_file);
    lock_release(&filesys_lock);
    exit(-1);
  }

  current_thread->fd_table[current_thread->next_fd] = current_file;
  int current_fd = current_thread->next_fd;

  while(true) {
    if(current_thread->fd_table[current_thread->next_fd] == NULL)
      break;
    ++current_thread->next_fd;
    if(current_thread->next_fd == FD_TABLE_MAX_SLOT) {
      current_thread->next_fd = -1;
      break;
    }
  }
  lock_release(&filesys_lock);

  return current_fd;
}

int filesize(int fd) {
  if(fd < 0 || fd >= FD_TABLE_MAX_SLOT || thread_current()->fd_table[fd] == NULL)
    exit(-1);

  lock_acquire(&filesys_lock);
  int return_value = file_length(thread_current()->fd_table[fd]);
  lock_release(&filesys_lock);

  return return_value;
}

int read(int fd, void *buffer, unsigned size) {
  if(fd < 0 || fd >= FD_TABLE_MAX_SLOT || thread_current()->fd_table[fd] == NULL || is_valid_address(buffer) == false || size < 0)
    exit(-1);

  struct page_entry *target_page_entry = NULL;
  for(struct list_elem *current_element = list_begin(&frame_table), *end_element = list_end(&frame_table); current_element != end_element; current_element = list_next(current_element)) {
    target_page_entry = list_entry(current_element, struct page_entry, pfelem);
    if(target_page_entry->vm->vaddr == buffer)
        break;
  }
  if(target_page_entry != NULL) {
    target_page_entry->vm->is_immortal = true;
    //printf("immortal setup in read()\n"); // TODO: DEBUG
  }

  if(fd == STDIN_FILENO)
    return input_getc();
  else {
    lock_acquire(&filesys_lock);
    int return_value = file_read(thread_current()->fd_table[fd], buffer, size);
    lock_release(&filesys_lock);

    if(target_page_entry != NULL)
      target_page_entry->vm->is_immortal = false;
    return return_value;
  }
  if(target_page_entry != NULL)
    target_page_entry->vm->is_immortal = false;
}

int write(int fd, const void *buffer, unsigned size) {
  if(is_valid_address(buffer) == false || size < 0)
    exit(-1);

  struct page_entry *target_page_entry = NULL;
  for(struct list_elem *current_element = list_begin(&frame_table), *end_element = list_end(&frame_table); current_element != end_element; current_element = list_next(current_element)) {
    target_page_entry = list_entry(current_element, struct page_entry, pfelem);
    if(target_page_entry->vm->vaddr == buffer)
        break;
  }

  if(target_page_entry != NULL)
    target_page_entry->vm->is_immortal = true;

  if(fd == STDOUT_FILENO) 
    putbuf(buffer, size);
  else {
    struct file *target_file = thread_current()->fd_table[fd];
    if(fd < 0 || fd >= FD_TABLE_MAX_SLOT || target_file == NULL || is_inode_valid_directory(file_get_inode(target_file)))
      exit(-1);
    lock_acquire(&filesys_lock);
    int return_value = file_write(target_file, buffer, size);
    lock_release(&filesys_lock);

    if(target_page_entry != NULL)
      target_page_entry->vm->is_immortal = false;
    return return_value;
  }

  if(target_page_entry != NULL)
    target_page_entry->vm->is_immortal = false;
  return size;
}

void seek(int fd, unsigned poisiton) {
  if(fd < 0 || fd >= FD_TABLE_MAX_SLOT || thread_current()->fd_table[fd] == NULL)
    exit(-1);

  lock_acquire(&filesys_lock);
  file_seek(thread_current()->fd_table[fd], poisiton);
  lock_release(&filesys_lock);
}
unsigned tell(int fd) {
  if(fd < 0 || fd >= FD_TABLE_MAX_SLOT || thread_current()->fd_table[fd] == NULL)
    exit(-1);

  lock_acquire(&filesys_lock);
  int return_value = file_tell(thread_current()->fd_table[fd]);
  lock_release(&filesys_lock);
  return return_value;
}
void close(int fd) {
  struct thread *current_thread = thread_current();
  if(fd < 0 || fd >= FD_TABLE_MAX_SLOT || current_thread->fd_table[fd] == NULL)
    exit(-1);

  lock_acquire(&filesys_lock);
  file_close(current_thread->fd_table[fd]);
  lock_release(&filesys_lock);

  current_thread->fd_table[fd] = NULL;
  current_thread->next_fd = fd;
}

bool is_mmap_overlapped(void *vaddr_start, int number_of_pages) {
  struct thread *current_thread = thread_current();
  void *vaddr_end = vaddr_start + number_of_pages * PGSIZE;

  void *mmap_start = NULL, *mmap_end = NULL;
  for(struct list_elem *current_element = list_begin(&current_thread->mmap_table), *end_element = list_end(&current_thread->mmap_table); current_element != end_element; current_element = list_next(current_element)) {
    struct mmap_entry *target_mmap_entry = list_entry(current_element, struct mmap_entry, mfelem);
    for(struct list_elem *current_element_vm = list_begin(&target_mmap_entry->mapping_list), *end_element_vm = list_end(&target_mmap_entry->mapping_list); current_element_vm != end_element_vm; current_element_vm = list_next(current_element_vm)) {
      struct vm_entry *target_vm_entry = list_entry(current_element_vm, struct vm_entry, vmelem);

      mmap_start = target_vm_entry->vaddr;
      mmap_end = mmap_start + PGSIZE;
      if (!(vaddr_end <= mmap_start || vaddr_start >= mmap_end))
        return true;
    }
  }
  
  // check code/data segment
  if (vaddr_end > INITIAL_CODE_SEGMENT && vaddr_start < current_thread->data_top)
    return true; 

  // check stack
  if (vaddr_start >= thread_current()->current_stack_bottom || vaddr_end > PHYS_BASE)
    return true;

  return false; 
}

int mmap(int fd, void *addr) {
  struct thread *current_thread = thread_current();  
  lock_acquire(&filesys_lock);
  if(current_thread->fd_table[fd] == NULL || addr == NULL || is_user_vaddr(addr) == false || (uintptr_t)addr % PGSIZE != 0) {
    lock_release(&filesys_lock);
    return -1;
  }
  lock_release(&filesys_lock);

  struct mmap_entry *new_mmap_file = malloc(sizeof(struct mmap_entry));
  if(new_mmap_file == NULL)
    exit(-1);
  list_init(&new_mmap_file->mapping_list);
  new_mmap_file->map_id = current_thread->current_available_map_id;
  ++current_thread->current_available_map_id;

  lock_acquire(&filesys_lock);
  new_mmap_file->mapped_file = file_reopen(current_thread->fd_table[fd]);
  int read_bytes = file_length(new_mmap_file->mapped_file);
  new_mmap_file->number_of_pages = (read_bytes + PGSIZE - 1) / PGSIZE;
  if(is_mmap_overlapped(addr, new_mmap_file->number_of_pages) == true) {
    file_close(new_mmap_file->mapped_file);
    --current_thread->current_available_map_id;
    free(new_mmap_file);
    lock_release(&filesys_lock);
    return -1;
  }
  lock_release(&filesys_lock);

  int offset = 0;
  while (read_bytes > 0) {
    size_t page_read_bytes = read_bytes < PGSIZE ? read_bytes : PGSIZE;
    size_t page_zero_bytes = PGSIZE - page_read_bytes;

    struct vm_entry *new_page = malloc(sizeof(struct vm_entry));
    if(new_page == NULL)
      return false;
    new_page->vm_type = VM_FILE;
    new_page->is_stack = false;
    new_page->vaddr = addr;
    new_page->file = new_mmap_file->mapped_file;
    new_page->read_bytes = page_read_bytes;
    new_page->zero_bytes = page_zero_bytes;
    new_page->offset = offset;
    new_page->writable = true;
    new_page->swap_slot = -1;
    new_page->is_immortal = true;
    list_push_back(&new_mmap_file->mapping_list, &new_page->vmelem);

    /* Advance. */
    read_bytes -= page_read_bytes;
    addr += PGSIZE;
    offset += PGSIZE;
  }
  list_push_back(&current_thread->mmap_table, &new_mmap_file->mfelem);

  return new_mmap_file->map_id;
}
void munmap(int map_id) {
  struct thread *current_thread = thread_current();
  struct mmap_entry *target_mmap_entry = NULL;
  for(struct list_elem *current_element = list_begin(&current_thread->mmap_table), *end_element = list_end(&current_thread->mmap_table); current_element != end_element; current_element = list_next(current_element)) {
    target_mmap_entry = list_entry(current_element, struct mmap_entry, mfelem);
    if(target_mmap_entry->map_id == map_id) {
      list_remove(current_element);
      break;
    }
  }
  if(target_mmap_entry == NULL)
    exit(-1);
  lock_acquire(&paging_lock);
  for(struct list_elem *current_element = list_begin(&target_mmap_entry->mapping_list), *end_element = list_end(&target_mmap_entry->mapping_list); current_element != end_element;) {
    struct vm_entry *target_vm_entry = list_entry(current_element, struct vm_entry, vmelem);
    for(struct list_elem *current_element_page = list_begin(&frame_table), *end_element_page = list_end(&frame_table); current_element_page != end_element_page;) {
      struct page_entry *target_page_entry = list_entry(current_element_page, struct page_entry, pfelem);
      if(target_page_entry->vm == target_vm_entry) {
        list_remove(current_element_page);
        if(pagedir_is_dirty(target_page_entry->thread->pagedir, target_page_entry->vm->vaddr))
          file_write_at(target_page_entry->vm->file, pagedir_get_page(target_page_entry->thread->pagedir, target_page_entry->vm->vaddr), PGSIZE, target_page_entry->vm->offset); 
        palloc_free_page(pagedir_get_page(target_page_entry->thread->pagedir, target_page_entry->vm->vaddr));
        pagedir_clear_page(target_page_entry->thread->pagedir, target_page_entry->vm->vaddr);
        free(target_page_entry);
        break;
      }
      else
        current_element_page = list_next(current_element_page);
    }
    current_element = list_next(current_element);
    free(target_vm_entry);
  }
  file_close(target_mmap_entry->mapped_file);
  lock_release(&paging_lock);
  free(target_mmap_entry);
}


bool chdir(const char *path_original) {
  char path[PATH_MAX_LENGTH + 1];
  strlcpy(path, path_original, PATH_MAX_LENGTH);
  strlcat(path, "/0", PATH_MAX_LENGTH);

  char name[PATH_MAX_LENGTH + 1];
  struct dir *dir = parse_path(path, name);
  if(!dir)
    return false;
  dir_close(thread_current()->current_directory);
  thread_current()->current_directory = dir;
  return true;
}
bool mkdir(const char *dir) {
  return filesys_create_dir(dir);
}
bool readdir(int fd, char *name) {
  struct file *target_file = thread_current()->fd_table[fd];
  if(target_file == NULL)
    exit(-1);
  struct inode *target_inode = file_get_inode(target_file); 
  if(target_inode == NULL || is_inode_valid_directory(target_inode) == false)
    return false;
  struct dir *dir = dir_open(target_inode);
  if(dir == NULL)
    return false;

  bool was_parent_previously = false;
  if(strcmp(name, "..") == 0)
    was_parent_previously = true;

  int current_count;
  bool result = true;
  off_t *pos = (off_t *)target_file + 1;
  for(current_count = 0; current_count <= *pos && result; ++current_count)
    result = dir_readdir(dir, name);
  if(current_count <= *pos == false)
    ++(*pos);

  if(was_parent_previously && strcmp(name, "..") == 0)
    return false;

  if(strcmp(name, ".") == 0 || strcmp(name, "..") == 0)
    return readdir(fd, name);

  return result;
}
bool isdir(int fd) {
  struct file *target_file = thread_current()->fd_table[fd];

  if(target_file == NULL)
    exit(-1);
  return is_inode_valid_directory(file_get_inode(target_file));
}
block_sector_t inumber(int fd) {
  struct file *target_file = thread_current()->fd_table[fd];
  if(target_file == NULL)
    exit(-1);
  return inode_get_inumber(file_get_inode(target_file));
}


static void syscall_handler(struct intr_frame* f) {
  int *current_esp = f->esp;

  if(is_valid_address(current_esp) == false)
    return; 

  switch (current_esp[0])
  {
    case SYS_HALT: halt(); break;
    case SYS_EXIT: exit(current_esp[1]); break;
    case SYS_EXEC: f->eax = exec(current_esp[1]); break;
    case SYS_WAIT: f->eax = wait(current_esp[1]); break;
    case SYS_CREATE: f->eax = create(current_esp[1], current_esp[2]); break;
    case SYS_REMOVE: f->eax = remove(current_esp[1]); break;
    case SYS_OPEN: f->eax = open(current_esp[1]); break;
    case SYS_FILESIZE: f->eax = filesize(current_esp[1]); break;
    case SYS_READ: f->eax = read(current_esp[1], current_esp[2], current_esp[3]); break;
    case SYS_WRITE: f->eax = write(current_esp[1], current_esp[2], current_esp[3]); break;
    case SYS_SEEK: seek(current_esp[1], current_esp[2]); break;
    case SYS_TELL: f->eax = tell(current_esp[1]); break;
    case SYS_CLOSE: close(current_esp[1]); break;

    case SYS_MMAP: f->eax = mmap(current_esp[1], current_esp[2]); break;
    case SYS_MUNMAP: munmap(current_esp[1]); break;

    case SYS_CHDIR: f->eax = chdir(current_esp[1]); break;
    case SYS_MKDIR: f->eax = mkdir(current_esp[1]); break;
    case SYS_READDIR: f->eax = readdir(current_esp[1], current_esp[2]); break;
    case SYS_ISDIR: f->eax = isdir(current_esp[1]); break;
    case SYS_INUMBER: f->eax = inumber(current_esp[1]); break;
  
    default: /*printf("Default: %d\n",current_esp[0]); */ ;
  }
}