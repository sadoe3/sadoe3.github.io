#include "page.h"
#include "threads/palloc.h"
#include "threads/vaddr.h"
#include "threads/thread.h"
#include "filesys/file.h"
#include "userprog/process.h"
#include "userprog/pagedir.h"
#include "devices/block.h"
#include "userprog/syscall.h"

#define SWAP_SIZE 1024  // number of swap slots


bool setup_stack (void **esp) {
    uint8_t *kpage;
    bool success = false;

    kpage = palloc_get_page (PAL_USER | PAL_ZERO);
    
    uint8_t *current_stack_top = (PHYS_BASE - PGSIZE);
    if (kpage != NULL) {
        success = install_page (current_stack_top, kpage, true);
        if (success)
            *esp = PHYS_BASE;
        else
            palloc_free_page (kpage);
    }

    struct thread *current_thread = thread_current();
    // update supplemental page table
    struct vm_entry *new_page = malloc(sizeof(struct vm_entry));
    if(new_page == NULL)
      return false;
    new_page->vm_type = VM_ANON;
    new_page->is_stack = true;
    new_page->vaddr = current_stack_top;
    new_page->file = NULL;
    new_page->writable = true;
    new_page->swap_slot = -1;
    new_page->is_immortal = true;
    list_push_back(&current_thread->spt_table, &new_page->vmelem);


    // update frame table
    struct page_entry *new_page_frame = malloc(sizeof(struct page_entry));
    if(new_page_frame == NULL)
        return false;
    new_page_frame->thread = current_thread;
    new_page_frame->vm = new_page;
    lock_acquire(&paging_lock);
    list_push_back(&frame_table, &new_page_frame->pfelem);    
    lock_release(&paging_lock);

    return success;
}

bool swap_slots[SWAP_SIZE];
int allocate_swap_slot(void) {
    for (int current_slot = 0; current_slot < SWAP_SIZE; ++current_slot) {
        if (swap_slots[current_slot] == false) {
            swap_slots[current_slot] = true;
            return current_slot;
        }
    }
    return -1;  // no free slot available
}
void free_swap_slot(int swap_slot) {
    if (swap_slot >= 0 && swap_slot < SWAP_SIZE)
        swap_slots[swap_slot] = false;
}


void write_to_swap_space(struct page_entry *target_page) {
    int current_available_swap_slot = allocate_swap_slot();
    block_write(block_get_role(BLOCK_SWAP), current_available_swap_slot, pagedir_get_page(target_page->thread->pagedir, target_page->vm->vaddr));
    target_page->vm->swap_slot = current_available_swap_slot;
}
void read_from_swap_space(void *kpage, int swap_slot) {
    block_read(block_get_role(BLOCK_SWAP), swap_slot, kpage);
    free_swap_slot(swap_slot);
}

void evict_page(struct page_entry *target_page_frame) {
    if(target_page_frame == NULL)
        return;
    if(target_page_frame->vm->vm_type == VM_ANON) 
        write_to_swap_space(target_page_frame);
    else {
        if(pagedir_is_dirty(target_page_frame->thread->pagedir, target_page_frame->vm->vaddr))
            file_write_at(target_page_frame->vm->file, pagedir_get_page(target_page_frame->thread->pagedir, target_page_frame->vm->vaddr), PGSIZE, target_page_frame->vm->offset); 
    }   
    
    palloc_free_page(pagedir_get_page(target_page_frame->thread->pagedir, target_page_frame->vm->vaddr));
    pagedir_clear_page(target_page_frame->thread->pagedir, target_page_frame->vm->vaddr);
    free(target_page_frame);
}

bool handle_page_fault(struct vm_entry *target_vm_entry) {   
    uint8_t *kpage = palloc_get_page (PAL_USER | PAL_ZERO);
    if (kpage == NULL) {
        // page swap
        struct page_entry *target_page_entry = NULL;
        if(lock_held_by_current_thread(&filesys_lock) == false)
            lock_acquire(&filesys_lock);
        lock_acquire(&paging_lock);
        
        for(struct list_elem *current_element = list_begin(&frame_table), *end_element = list_end(&frame_table); current_element != end_element; current_element = list_next(current_element)) {
            target_page_entry = list_entry(current_element, struct page_entry, pfelem);
            if(target_page_entry->vm->is_immortal == false) {
                list_remove(current_element);
                break;
            }
            else 
                target_page_entry = NULL;
        }
        evict_page(target_page_entry);

        lock_release(&paging_lock);
        kpage = palloc_get_page (PAL_USER | PAL_ZERO);
        if(kpage == NULL) {
            lock_release(&filesys_lock);
            return false;
        }
    }

    // load the data from disk
    bool is_lock_already_owned = lock_held_by_current_thread(&filesys_lock);
    if(is_lock_already_owned == false)
        lock_acquire(&filesys_lock);
    if(target_vm_entry->vm_type != VM_ANON) {
        if(file_read_at(target_vm_entry->file, kpage, target_vm_entry->read_bytes, target_vm_entry->offset) != target_vm_entry->read_bytes) {
            palloc_free_page (kpage);
            lock_release(&filesys_lock);
            return false;
        }
    }
    else {
        // check the swap space to load the page if there is : SWAP IN
        if(target_vm_entry->swap_slot != -1) {
            read_from_swap_space(kpage, target_vm_entry->swap_slot);
            target_vm_entry->swap_slot = -1;
        }
    }
    if(is_lock_already_owned == false)
        lock_release(&filesys_lock);

    // update page table  
    if (!install_page (target_vm_entry->vaddr, kpage, target_vm_entry->writable))  {
        palloc_free_page (kpage);
        return false;
    }

    // update frame table
    struct page_entry *new_page_frame = malloc(sizeof(struct page_entry));
    if(new_page_frame == NULL)
        return false;
    new_page_frame->thread = thread_current();
    new_page_frame->vm = target_vm_entry;
    lock_acquire(&paging_lock);
    list_push_back(&frame_table, &new_page_frame->pfelem);
    lock_release(&paging_lock);

    return true;
}