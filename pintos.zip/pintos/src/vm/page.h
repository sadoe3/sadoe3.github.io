#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <list.h>
#include "threads/thread.h"

#define INITIAL_CODE_SEGMENT 0x08048000

struct lock paging_lock;

enum page_frame_type {
    VM_BIN,     /* code segment */
    VM_ANON,    /* stack, heap or anonymous */
    VM_FILE     /* file-backed page */
};

/* vm_entry for spt_table in each thread */
struct vm_entry {
    enum page_frame_type vm_type;          // type of page frame
    bool is_stack;                         // flag for stack growth
    void *vaddr;                           // virtual page
    int zero_bytes;                        // padding info
    
    // these are necessary to load the actual file from disk
    struct file *file;
    int read_bytes, offset;
    bool writable;

    int swap_slot;                     // needed to check whether it's related to swap space or not

    bool is_immortal;                  // prevent current page from being swapped out

    struct list_elem vmelem;           // List element for page table   
};

/* page_entry for frame_table */
struct page_entry {
    struct thread *thread;
    struct vm_entry *vm;

    struct list_elem pfelem;           // List element for frame table  
};

/* page_entry for frame_table */
struct mmap_entry {
    int map_id;
    int number_of_pages;
    struct file *mapped_file;
    struct list mapping_list;          // List for loaded vm_entry 

    struct list_elem mfelem;           // List element for mapping table  
};

bool setup_stack (void **esp); 
bool handle_page_fault(struct vm_entry *target_vm_entry);
void evict_page(struct page_entry *target_page_frame);

#endif /* vm/page.h */